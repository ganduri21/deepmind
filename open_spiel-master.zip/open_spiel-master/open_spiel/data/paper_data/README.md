# Paper data

This directory hosts data for reproducing paper results. Each paper should have
an associated directory, with data contained within.
